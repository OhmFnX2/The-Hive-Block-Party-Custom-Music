1. Make 1-25 Music part Folder (Use any Daw or Audio Edit)
2. And Copy to Example (Copy all in Folder): subpacks/.../sounds/hive/party/music/.../
3. new UUID in manifest.json
4. Edit Name in manifest.json
5. Done!!!

But edit name in The Hive UI is not have Now (Is so hard to make it)